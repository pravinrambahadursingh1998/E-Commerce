import mongoose from 'mongoose';
import colors from 'colors';


const connectDB = async()=>{
     try {
        const conn = await mongoose.connect("mongodb+srv://pravinrambahadursingh1998:v56bNR9arl2h44zB@proshop.qhixsmg.mongodb.net/proshop")
        console.log(`connected to MongoDB databases ${conn.connection.host}`.bgMagenta.white);
     } catch (error) {
      console.log(`Error in MongoDB  ${error}`.bgRed.white);  
     }
}

export default connectDB